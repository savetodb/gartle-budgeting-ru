USE master;
GO

DROP USER ba_accountant_01;
GO

DROP USER ba_accountant_02;
GO

DROP USER ba_admin_01;
GO

DROP USER ba_admin_02;
GO

DROP USER ba_analyst_01;
GO

DROP USER ba_analyst_02;
GO

DROP USER ba_developer_01;
GO

DROP USER ba_developer_02;
GO

DROP USER ba_user_101;
GO

DROP USER ba_user_102;
GO

DROP USER ba_user_201;
GO

DROP USER ba_user_202;
GO

DROP USER ba_user_301;
GO

DROP USER ba_user_302;
GO

DROP USER ba_user_401;
GO

DROP USER ba_user_402;
GO


DROP LOGIN ba_accountant_01;
GO

DROP LOGIN ba_accountant_02;
GO

DROP LOGIN ba_admin_01;
GO

DROP LOGIN ba_admin_02;
GO

DROP LOGIN ba_analyst_01;
GO

DROP LOGIN ba_analyst_02;
GO

DROP LOGIN ba_developer_01;
GO

DROP LOGIN ba_developer_02;
GO

DROP LOGIN ba_user_101;
GO

DROP LOGIN ba_user_102;
GO

DROP LOGIN ba_user_201;
GO

DROP LOGIN ba_user_202;
GO

DROP LOGIN ba_user_301;
GO

DROP LOGIN ba_user_302;
GO

DROP LOGIN ba_user_401;
GO

DROP LOGIN ba_user_402;
GO

